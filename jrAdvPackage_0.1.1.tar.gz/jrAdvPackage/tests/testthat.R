library("testthat")
test_check("jrAdvPackage")
