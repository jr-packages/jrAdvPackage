
<!-- README.md is generated from README.Rmd. Please edit that file -->

# Advanced Programming

[![Build
Status](https://api.travis-ci.org/rcourses/jrAdvPackage.png?branch=master)](https://travis-ci.org/rcourses/jrAdvPackage)

This is a teaching package created and used by [Jumping
Rivers](www.jumpingrivers.com). To install the package run the following
commands

``` r
install.packages("drat")
drat::addRepo("jr-packages")
install.packages("jrAdvPackage")
```

## TODO

  - Add in section on `testthat`
  - Add in section on `GitHub` and `travis`
